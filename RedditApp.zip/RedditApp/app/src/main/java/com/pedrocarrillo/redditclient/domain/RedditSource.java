package com.pedrocarrillo.redditclient.domain;

/**
 * Created by pedrocarrillo on 5/3/17.
 */

public class RedditSource {

    private String url;
    private int width;
    private int height;

    public String getUrl() {
        return url;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

}
