package com.pedrocarrillo.redditclient.domain;

/**
 * Created by pedrocarrillo on 5/3/17.
 */

public class RedditImage {

    private RedditSource source;
    private String id;

    public RedditSource getSource() {
        return source;
    }

    public String getId() {
        return id;
    }

}

