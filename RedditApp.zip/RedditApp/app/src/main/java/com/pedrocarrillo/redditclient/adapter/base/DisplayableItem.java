package com.pedrocarrillo.redditclient.adapter.base;

/**
 * Created by pedrocarrillo on 5/2/17.
 */

public interface DisplayableItem {
}
